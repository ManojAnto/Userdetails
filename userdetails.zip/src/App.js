import logo from './logo.svg';
import './style.css';
import React,{ Component } from 'react';
import { BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';

import Login from './components/Login';
import Userdetails from './components/Userdetails';
import Useredit from './components/Useredit';

class App extends Component {

 render() {
	//localStorage.setItem('userlogged', 'NO');
  return (
  <Router>
		<div className="App">
			<ol>
			{ localStorage.getItem('userlogged')!='YES' && 
			<li>
				<Link to="/Login">Login</Link>
			</li>
			}

			{ localStorage.getItem('userlogged')=='YES' && 
			<li>
			<Link to="/Userdetails">Userdetails</Link>
			</li>
			}
						
			</ol>
			<hr/>
			<Routes>
				
				<Route exact path='/Login' element={<Login/>}></Route>
				<Route exact path='/Userdetails' element={<Userdetails/>}></Route>
				<Route exact path='/Useredit' element={<Useredit/>}></Route>
           </Routes>
		</div>
	</Router>
  );
  }
}



export default App;
