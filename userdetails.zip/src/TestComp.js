import React, { Component } from 'react';
import Childone from './components/Childone';

class TestComp extends Component{

	constructor(props) {

		super(props);

		this.state = { count: 0 , childcount:5 };
		
	}
	
	componentWillMount() {

		console.log("componentWillMount()");

	}

	componentDidMount() {

		console.log("componentDidMount()");
		this.setState({ count: this.state.count+10 });
	}
	
	changeState() {

		this.setState({ count: this.state.count+1 });

	}
	
	changeChildState() {

		this.setState({ childcount: this.state.childcount+1 });

	}
	
	shouldComponentUpdate(nextProps, nextState) {

		console.log("shouldComponentUpdate()");

		return true;

	}

	componentWillUpdate() {

		console.log("componentWillUpdate()");

	}

	componentDidUpdate() {

		console.log("componentDidUpdate()");

	}
	
	render() {
		return (
		  <div>
		<Childone childUsercnt={this.state.childcount}/>
        <h1>Overall user count, {this.state.count}</h1>

        <h2>

          <a onClick={this.changeState.bind(this)}>Click Here!</a>
		  <br/>
		  <a onClick={this.changeChildState.bind(this)}>Update Child</a>

        </h2>

      </div>
		);
	}
}
export default TestComp;