import React from 'react'
import '../userstyle.css';


class Home extends React.Component{


    constructor(props){
        super(props);
        this.state={
            loginsuccess:false
        };
    }

    render(){
       

        return(<div>
            <h4>User Portal</h4>    
            <a href="/login">Login<a>
        </div>);

    }
}

export default Home;