import React from 'react'
import { Navigate } from 'react-router-dom';
import '../userstyle.css';


class Login extends React.Component{


    constructor(props){
        super(props);
        this.state={
            loginsuccess:false
        };
    }


    componentDidMount(){
       /* fetch("https://reqres.in/api/login")
        .then((res) => res.json())
        .then((json) => {
            console.log(json);
            this.setState({userdata:json,loaded:true});
            localStorage.setItem('userlogged', 'YES');
            console.log(localStorage.getItem('userlogged'));
        });*/
    }

    handleChange(e) {

            console.log(e.target.value); 
        this.setState({
          [e.target.name]: e.target.value,
        });
    }


    ulogin(){
        let error=0;
        console.log(this.state.username+""+this.state.password);
        if(this.state.username!="" && this.state.username=='eve.holt@reqres.in'){
            error=0;
        }else{
            error=1;
        }
        
        if(this.state.password!=""  &&  this.state.password=='cityslicka'){
            error=0;
        }else{
            error=1;
        }
        console.log(error);
        if(error==0){
            let _data = {
                email: "eve.holt@reqres.in",
                password: "cityslicka", 
              }
            //fetch("https://reqres.in/api/login")
            fetch('https://reqres.in/api/login', {
                method: "POST",
                body: JSON.stringify(_data),
                headers: {"Content-type": "application/json; charset=UTF-8"}
            })
            .then((res) => res.json())
            .then((resp) => {
                console.log(resp.token);
                if(resp.token!=""){
                // this.setState({userdata:resp,loaded:true});
                 this.setState({loginsuccess:true})
                 localStorage.setItem('userlogged', 'YES');
                }
            });
           
          
           // history.push("/Userdetails");
            //this.props.history.push('/Userdetails')
        }
    }

    render(){
       
        if (this.state.loginsuccess && localStorage.getItem('userlogged')=='YES') return <Navigate  to="/Userdetails" />;
        else 
        return(<div>
       <div className="login-page">
      <div className="form">
        <div className="login">
          <div className="login-header">
            <h3>LOGIN</h3>
            <p>Please enter your credentials to login.</p>
          </div>
        </div>
        <form className="login-form">
          <input type="text" placeholder="username"  name="username"   onChange={(event) => this.handleChange(event)}/>
          <input type="password" placeholder="password" name="password"  onChange={(event) => this.handleChange(event)}/>
          <button type="button" onClick={()=>this.ulogin()}>Sign-in</button>
          <p className="message"><a href="#">Recover Password</a> <a href="#">Signup</a></p>
        </form>
      </div>
    </div>
      
        </div>);
    }


}

export default Login;