import React from 'react'
import { Navigate } from 'react-router-dom';
import '../userstyle.css';

class Useredit extends React.Component{

    constructor(props){
        super(props);
        this.state={
            loaded:false,
            loginsuccess:false
        };
    }

    componentDidMount(){

    }

    render(){
        return(<div>

<div className="edit-page">
      <div className="form">
        <div className="edit">
          <div className="edit-header">
            <h3>Edit User</h3>
          </div>
        </div>
        <form className="edit-form">
          <input type="text" placeholder="firstname"  name="firstname"   onChange={(event) => this.handleChange(event)}/>
          <input type="text" placeholder="lastname" name="lastname"  onChange={(event) => this.handleChange(event)}/>
          <button type="button" onClick={()=>this.saveuser()}>Save</button>
 
        </form>
      </div>
    </div>


        </div>);
    }
}

export default Useredit;