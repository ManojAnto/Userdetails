import React from 'react'
import { Navigate } from 'react-router-dom';
import '../userstyle.css';

class Userdetails extends React.Component{

    constructor(props){
        super(props);
        this.state={
            loaded:false,
            loginsuccess:false,
            edituser:false,
            edituserfirstname:'',
            edituserlastname:'',
            editeduserid:''
        };
    }

    componentDidMount(){

        if(localStorage.getItem('userlogged')=='YES'){
        fetch("https://reqres.in/api/users?page=2")
        .then((res) => res.json())
        .then((json) => {
            console.log(json);
            this.setState({userdata:json,loaded:true});
            this.setState({loginsuccess:true})
        });
        }
    }

    useredit(userid){
        console.log(userid);
        this.setState({edituser:'YES',editeduserid:userid});


       
        //fetch("https://reqres.in/api/login")
        fetch('https://reqres.in/api/users/'+userid, {
            method: "GET"
        })
        .then((res) => res.json())
        .then((resp) => {
           
            this.setState({edituserfirstname:resp.data.first_name,edituserlastname:resp.data.last_name});
        });
    }




    updateUser(userid){
        console.log(this.state.edituserfirstname,this.state.editeduserid);
        //this.setState({edituser:'YES'});
         let _data = {
            first_name: this.state.edituserfirstname,
          }

       
        //fetch("https://reqres.in/api/login")
        fetch('https://reqres.in/api/users/'+userid, {
            method: "PUT",
            body: JSON.stringify(_data),
            headers: {"Content-type": "application/json; charset=UTF-8"}
        })
        .then((res) => res.json())
        .then((resp) => {
           
            //this.setState({edituser:'NO'});
        });
    }

    handleChange(e) {

        console.log(e.target.value); 
    this.setState({
      [e.target.name]: e.target.value,
    });
}


    logout(){
        console.log('logout');
        //localStorage.clear();
        this.setState({loginsuccess:false});
        localStorage.setItem('userlogged', 'NO');
    }

    render(){
        if (!this.state.loginsuccess && localStorage.getItem('userlogged')=='NO') return <Navigate  to="/Login" />;
        else if(this.state.edituser=='YES')
        return( <div className="edit-page">
            <div className="form">
            <div className="edit">
                <div className="edit-header">
                <h3>Edit User</h3>
                </div>
            </div>
            <form className="edit-form">
                <input type="text" placeholder="firstname"  name="edituserfirstname"  value={this.state.edituserfirstname} onChange={(event) => this.handleChange(event)}/>
                <input type="text" placeholder="lastname" name="edituserlastname"  value={this.state.edituserlastname} onChange={(event) => this.handleChange(event)}/>
                <button type="button" onClick={()=>this.updateUser(this.state.editeduserid)}>Save</button>

            </form>
            </div>
        </div>)
        else
        return(<div>

            <button type="button" onClick={()=>this.logout()}>Logout</button>
            <div className="tcontainer">

            <input
                placeholder="FirstName"
                type="text"
                onChange={(event) => this.handleChange(event)}
                name="fname"
                className="form-control"
                value={this.state.fname}
              />
               <input
                placeholder="Lastname"
                type="text"
                onChange={(event) => this.handleChange(event)}
                name="lname"
                className="form-control"
                value={this.state.lname}
              /> 
               <input
                placeholder="Enter Age"
                type="text"
                onChange={(event) => this.handleChange(event)}
                value={this.state.age}
                name="age"
                className="form-control"
              />   
            <button type="button" onClick={()=>this.adduser()}>Add User</button>
            <table className="customers">
        <thead><tr>
          <th>Id</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Age</th>
          <th>Action</th>
        </tr></thead>
        <tbody>
        {this.state.loaded &&
             this.state.userdata.data.map((useritem,index) => {
            return(
            <tr key={useritem.id}><td>{useritem.id}</td><td>{useritem.first_name}</td><td>{useritem.last_name}</td><td>25</td>
            <td onClick={()=>this.useredit(useritem.id)}>Edit</td></tr>
            );

            })
        }
        </tbody>
        </table>
        </div>
        </div>)

    }

}

export default Userdetails;